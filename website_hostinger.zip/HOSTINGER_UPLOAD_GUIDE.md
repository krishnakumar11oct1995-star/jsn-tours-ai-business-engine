# How to Upload to Hostinger (in 3 Minutes)

This folder contains the complete, pre-built website for **Jai Srimannarayana Tours & Travels**.
It requires **zero Python setup** or background daemons on Hostinger shared hosting.

## Method 1: Upload via Hostinger hPanel File Manager (Easiest)
1. Log in to your **Hostinger Control Panel (hPanel)**.
2. Go to **Websites** -> Select your domain -> Click **Manage**.
3. Under **Files**, click **File Manager**.
4. Double-click to open the **`public_html`** directory.
5. Delete any default `default.php` file if present.
6. Click the **Upload** icon (top right) -> Select **Archive** -> Upload `website_hostinger.zip`.
7. Right-click `website_hostinger.zip` inside `public_html` and click **Extract**.
8. Ensure all files (`index.html`, `destinations/`, `calculator/`, `static/`, `.htaccess`) are directly inside `public_html/`.
9. Visit your domain in your browser! Your website is live with 100% speed!

## Method 2: Upload via FTP (FileZilla)
1. In Hostinger hPanel, find your **FTP Accounts** credentials (Host, Username, Password, Port 21).
2. Connect FileZilla to your Hostinger server.
3. Open the remote folder `/public_html`.
4. Drag and drop all files and folders from `website_hostinger/` directly into `/public_html`.

## Key Features Included:
- **Clean URLs**: Works seamlessly at `yourdomain.com/destinations/india/uttar-pradesh/kashi-varanasi`.
- **Google SEO Ready**: Embedded Schema.org JSON-LD structured data on all destination pages.
- **Fast Speed**: HTML pre-rendered with Gzip compression and browser caching in `.htaccess`.
- **Direct WhatsApp Funnel**: Instant bookings routed to Ramesh at 9030780132.
